# TensorFlow Dataset Tutorial

This repository contains the notebook used in my medium article:

https://medium.com/@FrancescoZ/how-to-use-dataset-in-tensorflow-c758ef9e4428
